document.getElementById("produtos").innerHTML = `
  <ul>
    <li>Suplemento A - R$49,90</li>
    <li>Shake Verde - R$89,80</li>
  </ul>
`;
